<?php
require_once './model/ImagemDAO.php';
require_once './model/Imagem.php';

var_dump(new Imagem(true));