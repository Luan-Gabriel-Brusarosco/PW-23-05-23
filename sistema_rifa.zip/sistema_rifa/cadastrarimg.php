<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Imagens</title>
</head>
<body>
<form method="post">
  <label for="linkImg">Link Img:</label>
  <input type="text" id="linkImg" name="linkImg" required>
  <br>
  <input type="submit" value="Cadastrar">
</form>
    <?php
    require_once 'model/ImagemDAO.php';
    require_once 'model/Imagem.php';
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        $link_img = $_POST['linkImg'];
    
      $imagem = new Imagem(true, 0, "", $link_img, 'CURRENT_TIMESTAMP', 'CURRENT_TIMESTAMP');
    
      var_dump($imagem);

      $imagemDAO = new ImagemDAO();
      $imagem = $imagemDAO->insert($imagem);
      if($imagem){
        var_dump($imagem);
      }
      else{
        var_dump($imagemDAO->getErro());
      }         
      
    }
    ?>
</body>
</html>